# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['samplelib']

package_data = \
{'': ['*']}

install_requires = \
['pandas>=1.2.4,<2.0.0', 'pytest>=6.2.4,<7.0.0']

setup_kwargs = {
    'name': 'samplelib',
    'version': '0.1.0',
    'description': 'Sample package that are installed',
    'long_description': None,
    'author': 'Shin Saito',
    'author_email': 'shinsa@jp.ibm.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9.5,<3.10.0',
}


setup(**setup_kwargs)
